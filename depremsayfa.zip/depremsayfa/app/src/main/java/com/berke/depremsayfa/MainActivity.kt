import android.R
import android.os.Bundle
import android.view.View
import android.widget.ImageButton
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity

internal class MainActivity : AppCompatActivity() {
    protected fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val expandableLayout1: LinearLayout = findViewById(R.id.expandableLayout1)
        val arrowImageButton1: ImageButton = findViewById(R.id.arrowImageButton1)
        val expandableLayout2: LinearLayout = findViewById(R.id.expandableLayout2)
        val arrowImageButton2: ImageButton = findViewById(R.id.arrowImageButton2)
        arrowImageButton1.setOnClickListener {
            if (expandableLayout1.visibility == View.GONE) {
                expandableLayout1.visibility = View.VISIBLE
            } else {
                expandableLayout1.visibility = View.GONE
            }
        }
        arrowImageButton2.setOnClickListener {
            if (expandableLayout2.visibility == View.GONE) {
                expandableLayout2.visibility = View.VISIBLE
            } else {
                expandableLayout2.visibility = View.GONE
            }
        }
    }
}