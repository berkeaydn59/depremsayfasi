import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;

public class MainActivity extends AppCompatActivity {


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final LinearLayout expandableLayout1 = findViewById(R.id.expandableLayout1);
        ImageButton arrowImageButton1 = findViewById(R.id.arrowImageButton1);
        arrowImageButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (expandableLayout1.getVisibility() == View.GONE) {
                    expandableLayout1.setVisibility(View.VISIBLE);
                } else {
                    expandableLayout1.setVisibility(View.GONE);
                }
            }
        });

        final LinearLayout expandableLayout2 = findViewById(R.id.expandableLayout2);
        ImageButton arrowImageButton2 = findViewById(R.id.arrowImageButton2);
        arrowImageButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (expandableLayout2.getVisibility() == View.GONE) {
                    expandableLayout2.setVisibility(View.VISIBLE);
                } else {
                    expandableLayout2.setVisibility(View.GONE);
                }
            }
        });
    }
}